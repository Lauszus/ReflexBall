var searchData=
[
  ['striker',['Striker',['../struct_striker.html',1,'']]]
];
