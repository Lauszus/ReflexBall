var searchData=
[
  ['savecursor',['saveCursor',['../ansi_8c.html#a42a5f2fda001ed7da5301aee510e4588',1,'saveCursor():&#160;ansi.c'],['../ansi_8h.html#a42a5f2fda001ed7da5301aee510e4588',1,'saveCursor():&#160;ansi.c']]],
  ['scrollall',['scrollAll',['../reflexball_8c.html#a91994f46a43b269fbdab4f931adc9438',1,'scrollAll():&#160;reflexball.c'],['../reflexball_8h.html#a91994f46a43b269fbdab4f931adc9438',1,'scrollAll():&#160;reflexball.c']]],
  ['scrolllevelup',['scrollLevelUp',['../reflexball_8c.html#a60c0caf5a77a3928fdff842fb7f075db',1,'scrollLevelUp():&#160;reflexball.c'],['../reflexball_8h.html#a60c0caf5a77a3928fdff842fb7f075db',1,'scrollLevelUp():&#160;reflexball.c']]],
  ['scrollliveingameled',['scrollLiveInGameLED',['../reflexball_8c.html#ae5bc21647b99f051ac4e4ab46e7cbf45',1,'scrollLiveInGameLED():&#160;reflexball.c'],['../reflexball_8h.html#ae5bc21647b99f051ac4e4ab46e7cbf45',1,'scrollLiveInGameLED():&#160;reflexball.c']]],
  ['setballpos',['setBallPos',['../reflexball_8c.html#a27db471dfd1cbf9c5b5d3e2abdb634bf',1,'setBallPos(unsigned char x, unsigned char y):&#160;reflexball.c'],['../reflexball_8h.html#a27db471dfd1cbf9c5b5d3e2abdb634bf',1,'setBallPos(unsigned char x, unsigned char y):&#160;reflexball.c']]],
  ['showgameover',['showGameOver',['../asciidisplay_8c.html#af6c30e8fd8656312c4eb7136fcb436b8',1,'showGameOver():&#160;asciidisplay.c'],['../asciidisplay_8h.html#af6c30e8fd8656312c4eb7136fcb436b8',1,'showGameOver():&#160;asciidisplay.c']]],
  ['showscoreled',['showScoreLED',['../reflexball_8c.html#a7741558e79b1aefc9a9fab743a69e79f',1,'showScoreLED():&#160;reflexball.c'],['../reflexball_8h.html#a7741558e79b1aefc9a9fab743a69e79f',1,'showScoreLED():&#160;reflexball.c']]],
  ['showwon',['showWon',['../asciidisplay_8c.html#a8c27da4eb7d16b27ffa79e74fb05630d',1,'showWon():&#160;asciidisplay.c'],['../asciidisplay_8h.html#a8c27da4eb7d16b27ffa79e74fb05630d',1,'showWon():&#160;asciidisplay.c']]],
  ['sin',['sin',['../math_8c.html#a4e229fbd59dc7b644524c15651027cde',1,'sin(int val):&#160;math.c'],['../math_8h.html#a4e229fbd59dc7b644524c15651027cde',1,'sin(int val):&#160;math.c']]],
  ['startgame',['startGame',['../reflexball_8c.html#ab1f321a2f17fa8ba0f5ab4e2621fd6d6',1,'startGame():&#160;reflexball.c'],['../reflexball_8h.html#ab1f321a2f17fa8ba0f5ab4e2621fd6d6',1,'startGame():&#160;reflexball.c']]],
  ['startmenu',['startMenu',['../asciidisplay_8c.html#abf61a732597d7bd9bd4bece497810e87',1,'startMenu():&#160;asciidisplay.c'],['../asciidisplay_8h.html#abf61a732597d7bd9bd4bece497810e87',1,'startMenu():&#160;asciidisplay.c']]],
  ['stopgame',['stopGame',['../reflexball_8c.html#a51323c662673eed7ea64eb1db33cafe8',1,'stopGame():&#160;reflexball.c'],['../reflexball_8h.html#a51323c662673eed7ea64eb1db33cafe8',1,'stopGame():&#160;reflexball.c']]],
  ['strlen',['strlen',['../ansi_8c.html#ac60d087a0f92d744b41e074599428be0',1,'strlen(char *string):&#160;ansi.c'],['../ansi_8h.html#ac60d087a0f92d744b41e074599428be0',1,'strlen(char *string):&#160;ansi.c']]],
  ['strlen_5from',['strlen_rom',['../asciidisplay_8c.html#a0d00ea41f8158c84490c93c776e55e24',1,'strlen_rom(rom const char *string):&#160;asciidisplay.c'],['../asciidisplay_8h.html#a0d00ea41f8158c84490c93c776e55e24',1,'strlen_rom(rom const char *string):&#160;asciidisplay.c']]]
];
