var searchData=
[
  ['oldbuttonsboard',['oldButtonsBoard',['../asciidisplay_8c.html#a27529539cd5f98381757eca6f2062d66',1,'asciidisplay.c']]],
  ['oldbuttonswheel',['oldButtonsWheel',['../asciidisplay_8c.html#aa9cee4e30c6b9cc7d0b499f1b4f73f40',1,'asciidisplay.c']]],
  ['onlychuckascii',['onlyChuckAscii',['../ascii_8c.html#a6c72447956d0ca18eba5166d5f961fd7',1,'onlyChuckAscii():&#160;ascii.c'],['../ascii_8h.html#a6c72447956d0ca18eba5166d5f961fd7',1,'onlyChuckAscii():&#160;ascii.c']]],
  ['openeyesascii',['openEyesAscii',['../ascii_8c.html#a3cda424b87243ebc73d3c0a94eb0af72',1,'openEyesAscii():&#160;ascii.c'],['../ascii_8h.html#a3cda424b87243ebc73d3c0a94eb0af72',1,'openEyesAscii():&#160;ascii.c']]]
];
