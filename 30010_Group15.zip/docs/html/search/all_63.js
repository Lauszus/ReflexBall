var searchData=
[
  ['calculatedifficulty',['calculateDifficulty',['../asciidisplay_8c.html#a6abd8faa2150e3ea08b45dcfb8912a88',1,'calculateDifficulty():&#160;asciidisplay.c'],['../asciidisplay_8h.html#a6abd8faa2150e3ea08b45dcfb8912a88',1,'calculateDifficulty():&#160;asciidisplay.c']]],
  ['character_5fdata',['character_data',['../charset_8h.html#af72ffddb18e81e0722bba9c7be5e25b9',1,'charset.h']]],
  ['charset_2eh',['charset.h',['../charset_8h.html',1,'']]],
  ['checkiteration',['checkIteration',['../reflexball_8c.html#a086bc43bcf36176c39397b5fd1847eef',1,'checkIteration(unsigned char x, unsigned char y):&#160;reflexball.c'],['../reflexball_8h.html#a086bc43bcf36176c39397b5fd1847eef',1,'checkIteration(unsigned char x, unsigned char y):&#160;reflexball.c']]],
  ['chuckascii1',['chuckAscii1',['../ascii_8c.html#ad7f40342ecf94fb05ed59f199afdcc33',1,'chuckAscii1():&#160;ascii.c'],['../ascii_8h.html#ad7f40342ecf94fb05ed59f199afdcc33',1,'chuckAscii1():&#160;ascii.c']]],
  ['chuckascii2',['chuckAscii2',['../ascii_8c.html#ace19998c1f16a163fa84dc1cce7c97fd',1,'chuckAscii2():&#160;ascii.c'],['../ascii_8h.html#ace19998c1f16a163fa84dc1cce7c97fd',1,'chuckAscii2():&#160;ascii.c']]],
  ['chucknorrisascii',['chuckNorrisAscii',['../ascii_8c.html#aa6ffe898b57f1fb7ef90130927f76899',1,'chuckNorrisAscii():&#160;ascii.c'],['../ascii_8h.html#aa6ffe898b57f1fb7ef90130927f76899',1,'chuckNorrisAscii():&#160;ascii.c']]],
  ['chucknorristextascii',['chuckNorrisTextAscii',['../ascii_8c.html#a58f457a6f01531ccac085eb7ed7a40eb',1,'chuckNorrisTextAscii():&#160;ascii.c'],['../ascii_8h.html#a58f457a6f01531ccac085eb7ed7a40eb',1,'chuckNorrisTextAscii():&#160;ascii.c']]],
  ['clearbigball',['clearBigBall',['../reflexball_8c.html#ae8cdf5af5b914b4bbb12ce7784b3adb5',1,'clearBigBall(long x, long y):&#160;reflexball.c'],['../reflexball_8h.html#ae8cdf5af5b914b4bbb12ce7784b3adb5',1,'clearBigBall(long x, long y):&#160;reflexball.c']]],
  ['clearmenuball',['clearMenuBall',['../asciidisplay_8c.html#abe6812857be8924b731df2a41bb1a55a',1,'clearMenuBall(unsigned char x, unsigned char y):&#160;asciidisplay.c'],['../asciidisplay_8h.html#abe6812857be8924b731df2a41bb1a55a',1,'clearMenuBall(unsigned char x, unsigned char y):&#160;asciidisplay.c']]],
  ['clockled',['clockLed',['../_l_e_d_8c.html#aed1fa06ca3972c5710ec0882d851a1c3',1,'clockLed(unsigned char digit):&#160;LED.c'],['../_l_e_d_8h.html#aed1fa06ca3972c5710ec0882d851a1c3',1,'clockLed(unsigned char digit):&#160;LED.c']]],
  ['clreol',['clreol',['../ansi_8c.html#a24aca17c97bbc6e547a836df3d57be3a',1,'clreol():&#160;ansi.c'],['../ansi_8h.html#a24aca17c97bbc6e547a836df3d57be3a',1,'clreol():&#160;ansi.c']]],
  ['clrscr',['clrscr',['../ansi_8c.html#af3eac3ad203ab091baad010ef3f7ab0a',1,'clrscr():&#160;ansi.c'],['../ansi_8h.html#af3eac3ad203ab091baad010ef3f7ab0a',1,'clrscr():&#160;ansi.c']]],
  ['color',['color',['../ansi_8c.html#a42ce990f2c3eacf2dec2b2edf3863294',1,'color(unsigned char foreground, unsigned char background):&#160;ansi.c'],['../ansi_8h.html#a42ce990f2c3eacf2dec2b2edf3863294',1,'color(unsigned char foreground, unsigned char background):&#160;ansi.c']]],
  ['column',['column',['../_l_e_d_8c.html#a8ba4b901af67ef48659a6f6a64a2a981',1,'LED.c']]],
  ['congratulationsascii',['congratulationsAscii',['../ascii_8c.html#af9ab2b3dea3cbd5aac8fa56d4e0f2c29',1,'congratulationsAscii():&#160;ascii.c'],['../ascii_8h.html#af9ab2b3dea3cbd5aac8fa56d4e0f2c29',1,'congratulationsAscii():&#160;ascii.c']]],
  ['convertchar',['convertChar',['../_l_e_d_8c.html#ae1fcc6a99b5edc91410a3ca501001925',1,'convertChar(char input):&#160;LED.c'],['../_l_e_d_8h.html#ae1fcc6a99b5edc91410a3ca501001925',1,'convertChar(char input):&#160;LED.c']]],
  ['cos',['cos',['../math_8c.html#ad642ef70bd0fac40de9b9bc92fec5781',1,'cos(int val):&#160;math.c'],['../math_8h.html#ad642ef70bd0fac40de9b9bc92fec5781',1,'cos(int val):&#160;math.c']]]
];
