var searchData=
[
  ['ladyascii',['ladyAscii',['../ascii_8c.html#aee6843734c3e7288ad0d0f8224cef9d0',1,'ladyAscii():&#160;ascii.c'],['../ascii_8h.html#aee6843734c3e7288ad0d0f8224cef9d0',1,'ladyAscii():&#160;ascii.c']]],
  ['lastbally',['lastBallY',['../asciidisplay_8c.html#abb8935b194b487b03c0f66a3e4fef6c8',1,'asciidisplay.c']]],
  ['lastx',['lastX',['../reflexball_8c.html#a009171614df9fb68bc23ad42439c90e3',1,'reflexball.c']]],
  ['lasty',['lastY',['../reflexball_8c.html#a72b18826b491795f0f652d13cad8f735',1,'reflexball.c']]],
  ['ledbuf',['ledBuf',['../reflexball_8c.html#a2656379f56a7ece02948d5b48269788f',1,'reflexball.c']]],
  ['level',['level',['../reflexball_8c.html#a0d957bf1afecc6bd1ebcb451c7abe11d',1,'reflexball.c']]],
  ['levels',['levels',['../levels_8h.html#acd72c7d6435d72dfa761087fc0135a28',1,'levels.h']]],
  ['levelscore',['levelScore',['../reflexball_8c.html#ae06b2ed60c24e11ef7061623bde43441',1,'reflexball.c']]],
  ['lives',['lives',['../struct_brick.html#a8d8c91775e55f076beec4f598db3ae1e',1,'Brick::lives()'],['../reflexball_8c.html#a8d8c91775e55f076beec4f598db3ae1e',1,'lives():&#160;reflexball.c']]]
];
