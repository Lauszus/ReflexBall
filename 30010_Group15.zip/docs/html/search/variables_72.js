var searchData=
[
  ['restartgame',['restartGame',['../reflexball_8c.html#ae34cb774bb55e653a80952ccce72af41',1,'restartGame():&#160;reflexball.c'],['../reflexball_8h.html#ae34cb774bb55e653a80952ccce72af41',1,'restartGame():&#160;reflexball.c']]],
  ['runonce',['runOnce',['../_l_e_d_8c.html#a5d610de642e3dd06d06960a78158ad2b',1,'LED.c']]],
  ['runoncebuf',['runOnceBuf',['../reflexball_8c.html#a7e9255b441a41b1eae81d755fb51a970',1,'reflexball.c']]]
];
