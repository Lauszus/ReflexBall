var searchData=
[
  ['gameoverascii',['gameOverAscii',['../ascii_8c.html#adcaeb98cbfebb2b984c82aaea6211955',1,'gameOverAscii():&#160;ascii.c'],['../ascii_8h.html#adcaeb98cbfebb2b984c82aaea6211955',1,'gameOverAscii():&#160;ascii.c']]],
  ['gameport_2ec',['gameport.c',['../gameport_8c.html',1,'']]],
  ['gameport_2eh',['gameport.h',['../gameport_8h.html',1,'']]],
  ['gamestarted',['gameStarted',['../reflexball_8c.html#abe3e76450097c6898c6a046e1d983c5a',1,'reflexball.c']]],
  ['gametimer',['gameTimer',['../reflexball_8c.html#a31eaa58782029e51b278dd6c0b63fb02',1,'reflexball.c']]],
  ['getgameportbuttons',['getGameportButtons',['../gameport_8c.html#ab28c55861a5595cfacc04e01f6520725',1,'getGameportButtons():&#160;gameport.c'],['../gameport_8h.html#ab28c55861a5595cfacc04e01f6520725',1,'getGameportButtons():&#160;gameport.c']]],
  ['getsavedcursor',['getSavedCursor',['../ansi_8c.html#a7ff7895c1783d3451baa5a43c8388ef9',1,'getSavedCursor():&#160;ansi.c'],['../ansi_8h.html#a7ff7895c1783d3451baa5a43c8388ef9',1,'getSavedCursor():&#160;ansi.c']]],
  ['getterminalcoordinate',['getTerminalCoordinate',['../reflexball_8c.html#ac5ccd670cf29b2f8fa56c6bf511901b7',1,'getTerminalCoordinate(long input):&#160;reflexball.c'],['../reflexball_8h.html#ac5ccd670cf29b2f8fa56c6bf511901b7',1,'getTerminalCoordinate(long input):&#160;reflexball.c']]],
  ['gotoxy',['gotoxy',['../ansi_8c.html#a9ef2e230b1a50277b0ba7fc9eeaec789',1,'gotoxy(unsigned char x, unsigned char y):&#160;ansi.c'],['../ansi_8h.html#a9ef2e230b1a50277b0ba7fc9eeaec789',1,'gotoxy(unsigned char x, unsigned char y):&#160;ansi.c']]],
  ['gotoxyball',['gotoxyBall',['../reflexball_8c.html#a9338139a256727d5dae67401521b64e0',1,'gotoxyBall(long x, long y):&#160;reflexball.c'],['../reflexball_8h.html#a9338139a256727d5dae67401521b64e0',1,'gotoxyBall(long x, long y):&#160;reflexball.c']]],
  ['graphiccommand',['graphicCommand',['../ansi_8c.html#a5f3a6989f0c683aefb96bd41b848d6df',1,'graphicCommand(char command):&#160;ansi.c'],['../ansi_8h.html#a5f3a6989f0c683aefb96bd41b848d6df',1,'graphicCommand(char command):&#160;ansi.c']]]
];
