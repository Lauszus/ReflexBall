var searchData=
[
  ['max_5fdifficulty',['MAX_DIFFICULTY',['../reflexball_8h.html#a4b8f96edf5459f120db77f80275dfe5c',1,'reflexball.h']]]
];
