var searchData=
[
  ['ballposstriker',['ballPosStriker',['../reflexball_8c.html#ab13225207acf508d9b8a78aff0e604ff',1,'ballPosStriker():&#160;reflexball.c'],['../reflexball_8h.html#ab13225207acf508d9b8a78aff0e604ff',1,'ballPosStriker():&#160;reflexball.c']]],
  ['bgcolor',['bgcolor',['../ansi_8c.html#aa16a869cba0d3ec4b640d9efd659479c',1,'bgcolor(unsigned char background):&#160;ansi.c'],['../ansi_8h.html#aa16a869cba0d3ec4b640d9efd659479c',1,'bgcolor(unsigned char background):&#160;ansi.c']]],
  ['blink',['blink',['../ansi_8c.html#a93c1f783677999ffa3b8530add700ebc',1,'blink(char on):&#160;ansi.c'],['../ansi_8h.html#a93c1f783677999ffa3b8530add700ebc',1,'blink(char on):&#160;ansi.c']]]
];
