var searchData=
[
  ['x',['x',['../struct_t_vector.html#a3162ada50d1df39e0f0555ea3d60dea1',1,'TVector::x()'],['../struct_ball.html#a3162ada50d1df39e0f0555ea3d60dea1',1,'Ball::x()'],['../struct_striker.html#ac1d1eed6a8bbca26af335b9682a6475e',1,'Striker::x()'],['../struct_brick.html#ac1d1eed6a8bbca26af335b9682a6475e',1,'Brick::x()']]],
  ['x1',['x1',['../asciidisplay_8h.html#a3bf0a9080fb787b00460234b7ec31eed',1,'x1():&#160;reflexball.c'],['../reflexball_8c.html#a3bf0a9080fb787b00460234b7ec31eed',1,'x1():&#160;reflexball.c']]],
  ['x2',['x2',['../asciidisplay_8h.html#afe6471792bc070377bcea47cccfa2de0',1,'x2():&#160;reflexball.c'],['../reflexball_8c.html#afe6471792bc070377bcea47cccfa2de0',1,'x2():&#160;reflexball.c']]],
  ['xmax',['xMax',['../asciidisplay_8c.html#a496628127c6a3f417737d840ec61dc22',1,'asciidisplay.c']]],
  ['xmin',['xMin',['../asciidisplay_8c.html#abdcfa3d29efb4c5861d64f55e098ed95',1,'asciidisplay.c']]]
];
