var searchData=
[
  ['default_5fdifficulty',['DEFAULT_DIFFICULTY',['../reflexball_8h.html#aa224ccbb75b3ab3848b91a5a50b6f98c',1,'reflexball.h']]],
  ['down',['DOWN',['../ansi_8h.html#a4193cd1c8c2e6ebd0e056fa2364a663f',1,'ansi.h']]]
];
