var searchData=
[
  ['readadc',['readADC',['../gameport_8c.html#ad911fcda31601674439cf81f40e6ab40',1,'readADC(unsigned char channel):&#160;gameport.c'],['../gameport_8h.html#ad911fcda31601674439cf81f40e6ab40',1,'readADC(unsigned char channel):&#160;gameport.c']]],
  ['readbuttons',['readButtons',['../buttons_8c.html#a767ae69cf525d1980fac34cb8c5f5a28',1,'readButtons():&#160;buttons.c'],['../buttons_8h.html#a767ae69cf525d1980fac34cb8c5f5a28',1,'readButtons():&#160;buttons.c']]],
  ['readkey',['readkey',['../buttons_8c.html#a23a520041e6ffa69f23787de17c2cc2e',1,'readkey():&#160;buttons.c'],['../buttons_8h.html#a23a520041e6ffa69f23787de17c2cc2e',1,'readkey():&#160;buttons.c']]],
  ['readsteeringwheel',['readSteeringWheel',['../gameport_8c.html#a094e4dbc2cd33e2add04f8b7d6435309',1,'readSteeringWheel():&#160;gameport.c'],['../gameport_8h.html#a094e4dbc2cd33e2add04f8b7d6435309',1,'readSteeringWheel():&#160;gameport.c']]],
  ['resetbgcolor',['resetbgcolor',['../ansi_8c.html#af252889571561f74f6090ef4cabbc59c',1,'resetbgcolor():&#160;ansi.c'],['../ansi_8h.html#af252889571561f74f6090ef4cabbc59c',1,'resetbgcolor():&#160;ansi.c']]],
  ['reverse',['reverse',['../ansi_8c.html#a6049e2337d64f2af1a946c303555f628',1,'reverse(char on):&#160;ansi.c'],['../ansi_8h.html#a6049e2337d64f2af1a946c303555f628',1,'reverse(char on):&#160;ansi.c']]],
  ['rotate',['rotate',['../math_8c.html#a894b432f0e478bd2daff5b6978d10e8b',1,'rotate(TVector *v, int val):&#160;math.c'],['../math_8h.html#a894b432f0e478bd2daff5b6978d10e8b',1,'rotate(TVector *v, int val):&#160;math.c']]]
];
