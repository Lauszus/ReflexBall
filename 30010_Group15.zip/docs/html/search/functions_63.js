var searchData=
[
  ['calculatedifficulty',['calculateDifficulty',['../asciidisplay_8c.html#a6abd8faa2150e3ea08b45dcfb8912a88',1,'calculateDifficulty():&#160;asciidisplay.c'],['../asciidisplay_8h.html#a6abd8faa2150e3ea08b45dcfb8912a88',1,'calculateDifficulty():&#160;asciidisplay.c']]],
  ['checkiteration',['checkIteration',['../reflexball_8c.html#a086bc43bcf36176c39397b5fd1847eef',1,'checkIteration(unsigned char x, unsigned char y):&#160;reflexball.c'],['../reflexball_8h.html#a086bc43bcf36176c39397b5fd1847eef',1,'checkIteration(unsigned char x, unsigned char y):&#160;reflexball.c']]],
  ['clearbigball',['clearBigBall',['../reflexball_8c.html#ae8cdf5af5b914b4bbb12ce7784b3adb5',1,'clearBigBall(long x, long y):&#160;reflexball.c'],['../reflexball_8h.html#ae8cdf5af5b914b4bbb12ce7784b3adb5',1,'clearBigBall(long x, long y):&#160;reflexball.c']]],
  ['clearmenuball',['clearMenuBall',['../asciidisplay_8c.html#abe6812857be8924b731df2a41bb1a55a',1,'clearMenuBall(unsigned char x, unsigned char y):&#160;asciidisplay.c'],['../asciidisplay_8h.html#abe6812857be8924b731df2a41bb1a55a',1,'clearMenuBall(unsigned char x, unsigned char y):&#160;asciidisplay.c']]],
  ['clockled',['clockLed',['../_l_e_d_8c.html#aed1fa06ca3972c5710ec0882d851a1c3',1,'clockLed(unsigned char digit):&#160;LED.c'],['../_l_e_d_8h.html#aed1fa06ca3972c5710ec0882d851a1c3',1,'clockLed(unsigned char digit):&#160;LED.c']]],
  ['clreol',['clreol',['../ansi_8c.html#a24aca17c97bbc6e547a836df3d57be3a',1,'clreol():&#160;ansi.c'],['../ansi_8h.html#a24aca17c97bbc6e547a836df3d57be3a',1,'clreol():&#160;ansi.c']]],
  ['clrscr',['clrscr',['../ansi_8c.html#af3eac3ad203ab091baad010ef3f7ab0a',1,'clrscr():&#160;ansi.c'],['../ansi_8h.html#af3eac3ad203ab091baad010ef3f7ab0a',1,'clrscr():&#160;ansi.c']]],
  ['color',['color',['../ansi_8c.html#a42ce990f2c3eacf2dec2b2edf3863294',1,'color(unsigned char foreground, unsigned char background):&#160;ansi.c'],['../ansi_8h.html#a42ce990f2c3eacf2dec2b2edf3863294',1,'color(unsigned char foreground, unsigned char background):&#160;ansi.c']]],
  ['convertchar',['convertChar',['../_l_e_d_8c.html#ae1fcc6a99b5edc91410a3ca501001925',1,'convertChar(char input):&#160;LED.c'],['../_l_e_d_8h.html#ae1fcc6a99b5edc91410a3ca501001925',1,'convertChar(char input):&#160;LED.c']]],
  ['cos',['cos',['../math_8c.html#ad642ef70bd0fac40de9b9bc92fec5781',1,'cos(int val):&#160;math.c'],['../math_8h.html#ad642ef70bd0fac40de9b9bc92fec5781',1,'cos(int val):&#160;math.c']]]
];
