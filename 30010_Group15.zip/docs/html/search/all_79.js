var searchData=
[
  ['y',['y',['../struct_t_vector.html#a04ee6b20e6d3476ab1f51397993cfeef',1,'TVector::y()'],['../struct_ball.html#a04ee6b20e6d3476ab1f51397993cfeef',1,'Ball::y()'],['../struct_striker.html#ac553850cf16d4c4f5812f7411e2b2b5a',1,'Striker::y()'],['../struct_brick.html#ac553850cf16d4c4f5812f7411e2b2b5a',1,'Brick::y()']]],
  ['y1',['y1',['../asciidisplay_8h.html#abba6ac7f3f69ed8834948efbe4078c41',1,'y1():&#160;reflexball.c'],['../reflexball_8c.html#abba6ac7f3f69ed8834948efbe4078c41',1,'y1():&#160;reflexball.c']]],
  ['y2',['y2',['../asciidisplay_8h.html#a1a17173b9996134853f757e9e3f9980a',1,'y2():&#160;reflexball.c'],['../reflexball_8c.html#a1a17173b9996134853f757e9e3f9980a',1,'y2():&#160;reflexball.c']]],
  ['ymax',['yMax',['../asciidisplay_8c.html#a03fa1c7ecc0f6470794db233d35d2814',1,'asciidisplay.c']]],
  ['ymin',['yMin',['../asciidisplay_8c.html#af5240b8528265b7c9e2d8398d2e8bba8',1,'asciidisplay.c']]]
];
