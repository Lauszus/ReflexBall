var searchData=
[
  ['fgcolor',['fgcolor',['../ansi_8c.html#a84ff7b69a9c6f73f4473a9fc451ae880',1,'fgcolor(unsigned char foreground):&#160;ansi.c'],['../ansi_8h.html#a84ff7b69a9c6f73f4473a9fc451ae880',1,'fgcolor(unsigned char foreground):&#160;ansi.c']]]
];
