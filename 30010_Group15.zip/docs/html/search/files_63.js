var searchData=
[
  ['charset_2eh',['charset.h',['../charset_8h.html',1,'']]]
];
