var searchData=
[
  ['nlives',['NLIVES',['../reflexball_8h.html#ac06abb623573bb7afb8aa8ecb3e9b831',1,'reflexball.h']]],
  ['notpassascii',['notPassAscii',['../ascii_8c.html#a98e17ba23f453a8fcda3c4b8545edc30',1,'notPassAscii():&#160;ascii.c'],['../ascii_8h.html#a98e17ba23f453a8fcda3c4b8545edc30',1,'notPassAscii():&#160;ascii.c']]],
  ['nowtryascii',['nowTryAscii',['../ascii_8c.html#a2f53fc840e630d4ca0b3779affaf60f9',1,'nowTryAscii():&#160;ascii.c'],['../ascii_8h.html#a2f53fc840e630d4ca0b3779affaf60f9',1,'nowTryAscii():&#160;ascii.c']]]
];
