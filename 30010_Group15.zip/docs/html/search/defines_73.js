var searchData=
[
  ['scroll_5fspeed',['SCROLL_SPEED',['../_l_e_d_8h.html#a4e7c3fad71f0d2ad019992d63364194e',1,'LED.h']]],
  ['sin_5fsize',['SIN_SIZE',['../lut_8h.html#aa2541fb34596132fb99dc3ce0f613447',1,'lut.h']]],
  ['striker_5fmax_5fangle',['STRIKER_MAX_ANGLE',['../reflexball_8h.html#a33f4b9112b2e3fe20559de418c9979a8',1,'reflexball.h']]],
  ['striker_5fmax_5fwidth',['STRIKER_MAX_WIDTH',['../reflexball_8h.html#a6236e236a4b8ed3cf477040994bfc21e',1,'reflexball.h']]]
];
