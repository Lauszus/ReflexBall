var searchData=
[
  ['back',['BACK',['../ansi_8h.html#ab303ee384877c80cb8855bf0113faf88',1,'ansi.h']]],
  ['ball_5fheight',['BALL_HEIGHT',['../reflexball_8h.html#a63e30a0ebc174fbdc445f8c6a37138ec',1,'reflexball.h']]],
  ['ball_5fwidth',['BALL_WIDTH',['../reflexball_8h.html#a59f2c3dacc9e6102981fac70883b296e',1,'reflexball.h']]],
  ['brick_5ftable_5fheight',['BRICK_TABLE_HEIGHT',['../reflexball_8h.html#a2567173a9f10f610180105fc912e49e8',1,'reflexball.h']]],
  ['brick_5ftable_5fwidth',['BRICK_TABLE_WIDTH',['../reflexball_8h.html#a0622e3e2d2e398a024e806fe64d92cf6',1,'reflexball.h']]]
];
