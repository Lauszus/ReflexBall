var searchData=
[
  ['score',['score',['../reflexball_8c.html#a9dffb288f0f2281a0b9abbd8efaa5a18',1,'reflexball.c']]],
  ['sin',['SIN',['../lut_8c.html#ade3e2de51dd0953ad416e83c3d457cfe',1,'SIN():&#160;lut.c'],['../lut_8h.html#ade3e2de51dd0953ad416e83c3d457cfe',1,'SIN():&#160;lut.c']]],
  ['startstring',['startString',['../asciidisplay_8c.html#ad76825230b77a44b122917e2ceb4ca24',1,'asciidisplay.c']]],
  ['striker',['striker',['../reflexball_8c.html#aa1de4112cc8e233266a80b90e800244f',1,'reflexball.c']]],
  ['strikerangle',['strikerAngle',['../reflexball_8c.html#aa597b160e50d331357b8d2faf589f920',1,'reflexball.c']]],
  ['strikerwidth',['strikerWidth',['../reflexball_8c.html#a6f1829bf07ffa53e63cc5720b9f8af1f',1,'strikerWidth():&#160;reflexball.c'],['../reflexball_8h.html#a6f1829bf07ffa53e63cc5720b9f8af1f',1,'strikerWidth():&#160;reflexball.c']]],
  ['stringlength',['stringLength',['../_l_e_d_8c.html#afe2f270141f48f41b1f35f29d80e96a1',1,'LED.c']]]
];
