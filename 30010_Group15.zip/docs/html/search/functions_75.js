var searchData=
[
  ['underline',['underline',['../ansi_8c.html#a7fcc0073e4f544a4b094ee02ef04316a',1,'underline(char on):&#160;ansi.c'],['../ansi_8h.html#a7fcc0073e4f544a4b094ee02ef04316a',1,'underline(char on):&#160;ansi.c']]],
  ['updategame',['updateGame',['../reflexball_8c.html#a97feb8702b4bc47a3dee7bf3b220da2b',1,'updateGame():&#160;reflexball.c'],['../reflexball_8h.html#a97feb8702b4bc47a3dee7bf3b220da2b',1,'updateGame():&#160;reflexball.c']]],
  ['updatemenu',['updateMenu',['../asciidisplay_8c.html#a8423842b2b8f998779f5b17832cf1536',1,'updateMenu():&#160;asciidisplay.c'],['../asciidisplay_8h.html#a8423842b2b8f998779f5b17832cf1536',1,'updateMenu():&#160;asciidisplay.c']]]
];
