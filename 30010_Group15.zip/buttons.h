#ifndef _buttons_h_
#define _buttons_h_

// Public
void initButtons();
unsigned char readButtons();
unsigned char readkey();

#endif